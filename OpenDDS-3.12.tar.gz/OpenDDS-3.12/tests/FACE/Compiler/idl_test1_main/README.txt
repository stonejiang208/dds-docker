This test checks the generated stubs & skeltons from ../idl_test1_lib
for proper support of OpenDDS::DCPS::Serializer and _dcps_max_marshaled_size(),
_dcps_is_bounded() and OpenDDS::DCPS::gen_find_size().

The test does not take any parameters.

Run the test by:
  idl_test1

Or

  run_test.pl
