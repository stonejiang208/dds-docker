<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1252681385265" ID="Freemind_Link_965201174" MODIFIED="1264452373490">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <center>
      Latency<br />Tests
    </center>
  </body>
</html></richcontent>
<node CREATED="1252681475919" ID="_" MODIFIED="1267746845784" POSITION="right" TEXT="process=1">
<node CREATED="1252682008096" HGAP="-36" ID="Freemind_Link_212670317" MODIFIED="1267747755932" TEXT="participant=process1" VSHIFT="35">
<node CREATED="1252682080500" HGAP="-31" ID="Freemind_Link_45739009" MODIFIED="1267747762996" TEXT="topic=A" VSHIFT="28">
<node CREATED="1252682265361" HGAP="108" ID="Freemind_Link_356142554" MODIFIED="1267747882366" TEXT="subscription=s5" VSHIFT="18">
<node CREATED="1252685049603" ID="Freemind_Link_404191476" MODIFIED="1267742157454" TEXT="DataCollectionFile=latency.data">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1267742158238" ID="ID_1087869385" MODIFIED="1267742236667" TEXT="DataCollectionBound=5000">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1267742167910" ID="ID_1437293011" MODIFIED="1267742241283" TEXT="DataCollectionRetention=NEWEST">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1252682023701" HGAP="23" ID="Freemind_Link_1398263163" MODIFIED="1267830893599" TEXT="TransportIndex=2" VSHIFT="-4">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1252685039851" HGAP="24" ID="Freemind_Link_842900184" MODIFIED="1267830896607" TEXT="Partition=2">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1252682253139" HGAP="105" ID="Freemind_Link_251424740" MODIFIED="1267747874246" TEXT="publication=p1" VSHIFT="74">
<arrowlink COLOR="#0000ff" DESTINATION="Freemind_Link_1441693291" ENDARROW="Default" ENDINCLINATION="-138;103;" ID="Freemind_Arrow_Link_76254940" STARTARROW="None" STARTINCLINATION="-234;269;"/>
<node CREATED="1252684820712" ID="Freemind_Link_862022391" MODIFIED="1267742299977" TEXT="MessageSizeType=FIXED">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1267742279525" ID="ID_1535168322" MODIFIED="1267747718055" TEXT="MessageSize=%SIZE%">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1267742317489" ID="ID_1107698752" MODIFIED="1267742336701" TEXT="MessageRateType=FIXED">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1252684789289" ID="Freemind_Link_1026942330" MODIFIED="1267830848981" TEXT="MessageRate=100">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1264451454657" ID="ID_930516897" MODIFIED="1264451479170" TEXT="HistoryKind=KEEP_LAST">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1264451482235" ID="ID_1468306818" MODIFIED="1267745516628" TEXT="HistoryDepth=10" VSHIFT="1">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1267745494107" HGAP="21" ID="ID_1573862571" MODIFIED="1267745535348" TEXT="ResourceMaxSamplesPerInstance=10" VSHIFT="2">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1267746683592" ID="ID_1796173580" MODIFIED="1267746698649" TEXT="ReliabilityKind=RELIABLE">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1267746721816" ID="ID_759364078" MODIFIED="1267746732658" TEXT="ReliabilityMaxBlocking=0">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1252682017416" ID="Freemind_Link_1889360776" MODIFIED="1267745868386" TEXT="TransportIndex=1">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1267746124614" ID="ID_1008815700" MODIFIED="1267746131775" TEXT="Associations=1">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1252684845982" ID="Freemind_Link_1136854002" MODIFIED="1267830876645" TEXT="Partition=1">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1267745579329" HGAP="32" ID="ID_301959425" MODIFIED="1267747860846" TEXT="ReliabilityKind=RELIABLE" VSHIFT="-140">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
</node>
<node CREATED="1252681487676" ID="Freemind_Link_1840459449" MODIFIED="1267746858999" POSITION="left" TEXT="process=2">
<node CREATED="1252682030904" HGAP="5" ID="Freemind_Link_294397180" MODIFIED="1267747768148" TEXT="participant=process2" VSHIFT="-32">
<node CREATED="1252682094982" HGAP="-5" ID="Freemind_Link_1391651102" MODIFIED="1267747771572" TEXT="topic=A" VSHIFT="-41">
<node CREATED="1252682213030" HGAP="22" ID="Freemind_Link_409254591" MODIFIED="1267747696291" TEXT="publication=p3" VSHIFT="-26">
<arrowlink COLOR="#0000ff" DESTINATION="Freemind_Link_356142554" ENDARROW="Default" ENDINCLINATION="-84;-354;" ID="Freemind_Arrow_Link_1251670429" STARTARROW="None" STARTINCLINATION="-243;-76;"/>
<node CREATED="1252685314028" ID="Freemind_Link_1869083703" MODIFIED="1253129753068" TEXT="MessageSource=s1">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1252682036113" ID="Freemind_Link_1123395982" MODIFIED="1267746083878" TEXT="TransportIndex=2">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1252685328982" ID="Freemind_Link_1333944074" MODIFIED="1267830907493" TEXT="Partition=2">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1252682230711" HGAP="19" ID="Freemind_Link_1441693291" MODIFIED="1267747702418" TEXT="subscription=s1" VSHIFT="-20">
<arrowlink COLOR="#0000ff" DESTINATION="Freemind_Link_409254591" ENDARROW="Default" ENDINCLINATION="367;-183;" ID="Freemind_Arrow_Link_25353627" STARTARROW="None" STARTINCLINATION="256;11;"/>
<node CREATED="1252682040141" HGAP="25" ID="Freemind_Link_584977990" MODIFIED="1267830917784" TEXT="TransportIndex=1" VSHIFT="14">
<icon BUILTIN="button_ok"/>
</node>
<node CREATED="1252685243907" HGAP="26" ID="Freemind_Link_451789155" MODIFIED="1267830920424" TEXT="Partition=1" VSHIFT="2">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node CREATED="1267745617975" ID="ID_169951598" MODIFIED="1267830718221" TEXT="ReliabilityKind=RELIABLE">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
</node>
</node>
</map>
